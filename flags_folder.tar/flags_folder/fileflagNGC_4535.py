sdflag(infile = 'uid___A002_Xb1d975_X2260.ms.PM02.asap',
  mode = 'manual',
  scan = '11,12',
  overwrite = True)
sdflag(infile = 'uid___A002_Xb1d975_X2260.ms.PM03.asap',
  mode = 'manual',
  scan = '11,12',
  overwrite = True)
sdflag(infile = 'uid___A002_Xb1d975_X2260.ms.PM04.asap',
  mode = 'manual',
  scan = '11,12',
  overwrite = True)

